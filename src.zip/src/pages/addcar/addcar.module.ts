import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddcarPage } from './addcar';

@NgModule({
  declarations: [
    AddcarPage,
  ],
  imports: [
    IonicPageModule.forChild(AddcarPage),
  ],
})
export class AddcarPageModule {}
