import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditcarPage } from './editcar';

@NgModule({
  declarations: [
    EditcarPage,
  ],
  imports: [
    IonicPageModule.forChild(EditcarPage),
  ],
})
export class EditcarPageModule {}
