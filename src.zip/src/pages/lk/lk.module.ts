import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LkPage } from './lk';

@NgModule({
  declarations: [
    LkPage,
  ],
  imports: [
    IonicPageModule.forChild(LkPage),
  ],
})
export class LkPageModule {}
