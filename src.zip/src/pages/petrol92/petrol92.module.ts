import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Petrol92Page } from './petrol92';

@NgModule({
  declarations: [
    Petrol92Page,
  ],
  imports: [
    IonicPageModule.forChild(Petrol92Page),
  ],
})
export class Petrol92PageModule {}
