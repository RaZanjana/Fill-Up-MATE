import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Petrol95Page } from './petrol95';

@NgModule({
  declarations: [
    Petrol95Page,
  ],
  imports: [
    IonicPageModule.forChild(Petrol95Page),
  ],
})
export class Petrol95PageModule {}
